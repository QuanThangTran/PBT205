﻿using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Text;

class Program
{
    static void Main(string[] args)
    {
        // Check if the required command-line argument is provided
        if (args.Length < 1)
        {
            Console.WriteLine("Usage: Program <middleware_endpoint>");
            return;
        }

        // Create a connection factory with the provided middleware endpoint
        var factory = new ConnectionFactory() { Uri = new Uri(args[0]) };

        // Check if the application is running as SendOrder or Exchange
        if (args.Length >= 4)
        {
            // SendOrder application
            SendOrder(factory, args);
        }
        else
        {
            // Exchange application
            Exchange(factory);
        }
    }

    static void SendOrder(ConnectionFactory factory, string[] args)
    {
        // Check if the required command-line arguments are provided for SendOrder
        if (args.Length < 5)
        {
            Console.WriteLine("Usage: Program <middleware_endpoint> <username> <SIDE> <PRICE>");
            return;
        }

        // Create a connection and channel
        using (var connection = factory.CreateConnection())
        using (var channel = connection.CreateModel())
        {
            // Declare a queue named "orders" if it doesn't exist
            channel.QueueDeclare(queue: "orders",
                                 durable: false,
                                 exclusive: false,
                                 autoDelete: false,
                                 arguments: null);

            // Construct the message with order details
            string message = $"{args[1]} {args[2]} {args[3]} 100 {args[4]}";
            var body = Encoding.UTF8.GetBytes(message);

            // Publish the order message to the "orders" queue
            channel.BasicPublish(exchange: "",
                                 routingKey: "orders",
                                 basicProperties: null,
                                 body: body);
            Console.WriteLine("Order sent: {0}", message);
        }
    }

    static void Exchange(ConnectionFactory factory)
    {
        // Create a connection and channel
        using (var connection = factory.CreateConnection())
        using (var channel = connection.CreateModel())
        {
            // Declare queues for orders and trades if they don't exist
            channel.QueueDeclare(queue: "orders",
                                 durable: false,
                                 exclusive: false,
                                 autoDelete: false,
                                 arguments: null);

            channel.QueueDeclare(queue: "trades",
                                 durable: false,
                                 exclusive: false,
                                 autoDelete: false,
                                 arguments: null);

            // Setup a consumer to receive messages from the "orders" queue
            var consumer = new EventingBasicConsumer(channel);
            consumer.Received += (model, ea) =>
            {
                var body = ea.Body.ToArray();
                var message = Encoding.UTF8.GetString(body);
                Console.WriteLine("Received order: {0}", message);
                // Logic for processing the order and checking matches
            };
            // Start consuming messages from the "orders" queue
            channel.BasicConsume(queue: "orders",
                                 autoAck: true,
                                 consumer: consumer);

            Console.WriteLine("Press [enter] to exit.");
            Console.ReadLine();
        }
    }
}
